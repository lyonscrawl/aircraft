Voici les quelques instructions avant de lancer notre programme :
	- Conservez le dossier "pics" avec les autres fichiers
	- Installez les librairies labltk
	- Entrez dans le dossier "projet" depuis le terminal et tapez la commande : ocamlopt.opt -o projet -I +labltk labltk.cmxa view.mli view.ml avion.mli avion.ml conflit.mli conflit.ml trajectoire.mli trajectoire.ml vol.mli vol.ml liste_pos.mli liste_pos.ml pos_avion.mli pos_avion.ml annexe.mli annexe.ml affichage.mli affichage.ml probleme.mli probleme.ml algo_gen.mli algo_gen.ml simulation.mli simulation.ml projet.ml && ./projet
	- Cela peut arriver que le programme ne fonctionne pas au premier lancer. Dans ce cas, pas de panique, il fonctionne forcément au second. Vous pouvez compilez à nouveau ou juste faire ./projet


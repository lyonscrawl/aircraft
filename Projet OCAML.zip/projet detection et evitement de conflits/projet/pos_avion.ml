
type pos_avion = { plane: Avion.avion; position: View.xy; instant: float; azimut:float; list_pos:Liste_pos.liste_pos; prochaine_pos:int};; (*l'azimut est en radians*)

let creer_pos = fun avi pos tps ->
	{ plane = avi; position = pos; instant = tps;azimut=0.;list_pos=Liste_pos.create_liste avi;prochaine_pos=0};;
	
let recup_coords = fun pos ->
	pos.position;;
	
let recup_avion = fun pos ->
	pos.plane;;
	
let recup_tps = fun pos ->
	pos.instant;;
	
let recup_azimut = fun pos ->
	pos.azimut;;
	
let recup_liste = fun pos ->
	pos.list_pos;;
	
let recup_next = fun pos ->
	pos.prochaine_pos;;
	
let initialiser_azimut = fun pos traj -> 
	let azim = Trajectoire.calcul_azimut traj in 
	{plane=pos.plane;position=pos.position;instant=pos.instant; azimut=azim;list_pos=pos.list_pos;prochaine_pos=pos.prochaine_pos};;
	
let sorti = fun x y taille_fenetre ->
	x>(taille_fenetre-.100.)||y>(taille_fenetre-.100.)||x<100.||y<100.;;

let maj_pos = fun pos vol pas ->
	let liste = Liste_pos.implementer_pos vol pas in
	{ plane = pos.plane; position = pos.position; instant = pos.instant;azimut=pos.azimut;list_pos=liste;prochaine_pos=1};;


	
let effectuer_man = fun pos t0 t1 alpha pas azim_prev taille->
	let liste,pts=Liste_pos.modifie_traj pos.list_pos t0 t1 alpha pas (Avion.recup_vitesse pos.plane) azim_prev taille in
	({plane=pos.plane;position=pos.position;instant=pos.instant; azimut=pos.azimut;list_pos=liste;prochaine_pos=pos.prochaine_pos},pts);;
	
let avancer_avion = fun pos temps ->
	let (((x,y),(t,azim)),ind) = Liste_pos.chercher_une_pos (Liste_pos.recup_pos pos.list_pos) pos.prochaine_pos in
	{ plane= pos.plane; position= (x,y); instant= t; azimut=azim; list_pos=pos.list_pos; prochaine_pos=ind};;

	
let distance = fun pos1 pos2 ->
	let x1,y1 = pos1.position and x2,y2 = pos2.position in
	sqrt((x1-.x2)**2.+.(y1-.y2)**2.);;
	

	
	

	


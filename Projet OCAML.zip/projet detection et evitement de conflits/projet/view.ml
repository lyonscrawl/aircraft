type xy = float * float
type base = float * float * float * float
type toplevel = Widget.toplevel Widget.widget
type canvas = Widget.canvas Widget.widget

type anchor = [ `Center | `E | `N | `Ne | `Nw | `S | `Se | `Sw | `W ]

type arrowStyle = [ `Both | `First | `Last | `None ]

type color =
  [`Black | `Red | `Green | `Yellow | `Blue | `White | `Color of string]

let openTk = Tk.openTk
let closeTk = Tk.closeTk
let update = Tk.update
let mainLoop = Tk.mainLoop

let token s = Protocol.TkToken s

let command cmd =
  Protocol.tkCommand (Array.map token cmd)
  
let eval cmd =
  Protocol.tkEval (Array.map token cmd)

let sof = string_of_float
let soi = string_of_int
let fos = float_of_string
let ios = int_of_string
        
let basetag = "scale"

let set_base cv (x0, y0, dx, dy) =
  let x1 = x0 +. dx and y1 = y0 +. dy in
  command [|Widget.name cv; "create"; "line"; sof x0; sof y0; sof x1; sof y1;
            "-fill"; ""; "-tag"; basetag|]

let get_base cv =
  match Canvas.coords_get cv (`Tag basetag) with
  | x0::y0::x1::y1::_ -> (x0, y0, x1 -. x0, y1 -. y0)
  | _ -> (0., 0., 1., 1.)

let to_cv (x0, y0, dx, dy) (x, y) =
  (x0 +. dx *. x, y0 +. dy *. y)

let from_cv (x0, y0, dx, dy) (x, y) =
  ((x -. x0) /. dx, (y -. y0) /. dy)
    
let canvas ?(width=2000) ?(height=1000) ?(background=`White) w =
  let cv = Canvas.create ~width ~height ~background w in
  set_base cv (0., 0., 1., 1.);
  Tk.bind ~events:[`KeyPressDetail "q"] ~action:(fun _ ->
  let dialog = Dialog.create
  ~parent:w
  ~title:"Fermerture de l'application"
  ~message:"Voulez-vous réellement fermer le projet ?"
  ~buttons:["Oui";"Non"]
  ~default:1
  ()
  in
  if dialog=0 then (print_endline "Bye"; flush stdout; closeTk ())
  else (print_endline "OK"; flush stdout)) cv;
  Focus.set cv;
  cv

let to_id = function `Id i -> i | `Tag s -> ios s

let to_tag = function `Id i -> soi i | `Tag s -> s

let set_coords cv id xys =
  let cmd = Array.make (3 + 2 * List.length xys) (token "") in
  cmd.(0) <- token (Widget.name cv);
  cmd.(1) <- token "coords";
  cmd.(2) <- token (soi id);
  let base = get_base cv in
  List.iteri
    (fun i xy ->
      let (xc, yc) = to_cv base xy in
      let j = 3 + 2 * i in
      cmd.(j) <- token (sof xc);
      cmd.(j + 1) <- token (sof yc))
    xys;
  Protocol.tkCommand cmd

let get_coords cv id =
  let base = get_base cv in
  let rec get = function
    | x::y::tl -> from_cv base (x, y)::get tl
    | _ -> [] in
  get (Canvas.coords_get cv (`Id id))

let gen_create cv item xys =
  let id = to_id item in
  set_coords cv id xys;
  id

let text
      ?(anchor=`Center)
      ?(fill=`Black)
      ?(font="TkDefaultFont")
      ?(text="")
      ?(tags=[])
      xy cv =
  let item = Canvas.create_text
               ~x:0 ~y:0 ~anchor ~fill ~font ~text ~tags cv in
  gen_create cv item [xy]

  
let rectangle
      ?(outline=`Black)
      ?(fill=`Color "")
      ?(width=1)
      ?(tags=[])
      xys cv =
  let item = Canvas.create_rectangle
               ~x1:0 ~y1:0 ~x2:0 ~y2:0 ~outline ~fill ~width ~tags cv in
  gen_create cv item xys

let oval
      ?(outline=`Black)
      ?(fill=`Color "")
      ?(width=1)
      ?(tags=[])
      xys cv =
  let item = Canvas.create_oval
               ~x1:0 ~y1:0 ~x2:0 ~y2:0 ~outline ~fill ~width ~tags cv in
  gen_create cv item xys

let line
      ?(fill=`Black)
      ?(width=1)
      ?(arrow=`None)
      ?(tags=[])
      xys cv =
  let item = Canvas.create_line
               ~xys:[(0,0);(0,0)] ~fill ~width ~arrow ~tags cv in
  gen_create cv item xys
             
let polygon
      ?(outline=`Black)
      ?(fill=`Color "")
      ?(width=1)
      ?(tags=[])
      xys cv =
  let item = Canvas.create_polygon
               ~xys:[(0,0);(0,0)] ~outline ~fill ~width ~tags cv in
  gen_create cv item xys

let move_tag cv tag dx dy =
  let _, _, dxb, dyb = get_base cv in
  command [|Widget.name cv; "move"; tag; sof (dx *. dxb); sof (dy *. dyb)|]

let move cv id = move_tag cv (soi id)

let scale_tag cv tag x y zx zy =
  let base = get_base cv in
  let (x0, y0) = to_cv base (x, y) in
  command [|Widget.name cv; "scale"; tag; sof x0; sof y0; sof zx; sof zy|]

let scale cv id = scale_tag cv (soi id)

let delete cv id = Canvas.delete cv [`Id id]
                 
let delete_tag cv tag = Canvas.delete cv [`Tag tag]

let see_all ?(tags=["all"]) cv =
  update ();
  let w = Winfo.width cv and h = Winfo.height cv in
  let base = get_base cv in
  Canvas.delete cv [`Tag basetag];
  let (x0, y0, x1, y1) =
    try Canvas.bbox cv (List.map (fun tag -> `Tag tag) tags)
    with _ -> (0, 0, w, h) in
  set_base cv base;
  let zoom = min (float w /. float (x1 - x0)) (float h /. float (y1 - y0)) in
  let wm = w / 2 and hm = h / 2 in
  Canvas.move cv (`Tag "all") (wm - (x1 + x0) / 2) (hm - (y0 + y1) / 2);
  Canvas.scale cv (`Tag "all") wm hm zoom zoom

let nav_bind cv =
  let xy = ref (0, 0) in
  let get_xy ev = (ev.Tk.ev_MouseX, ev.Tk.ev_MouseY) in
  let mouse_click ev =
    xy := get_xy ev in
  let mouse_drag ev =
    let (x, y) = get_xy ev in
    Canvas.move cv (`Tag "all") (x - fst !xy) (y - snd !xy);
    xy := (x, y) in
  let mouse_scale factor ev =
    let (x, y) = get_xy ev in
    Canvas.scale cv (`Tag "all") x y factor factor in
  let key_move dx dy ev =
    Canvas.move cv (`Tag "all") dx dy in
  let key_scale factor ev =
    let x = Winfo.width cv / 2 and y = Winfo.height cv / 2 in
    Canvas.scale cv (`Tag "all") x y factor factor in
  let bind ev action =
    Tk.bind ~events:ev ~fields:[`MouseX; `MouseY] ~action:action cv in
  bind [`ButtonPressDetail 1] mouse_click;
  bind [`Modified ([`Button1], `Motion)] mouse_drag;
  (* Unix mouse wheel *)
  bind [`ButtonPressDetail 4] (mouse_scale 1.1);
  bind [`ButtonPressDetail 5] (mouse_scale (1. /. 1.1));
  (* Key shortcuts *)
  let dx = 50 and z = 1.2 in
  bind [`KeyPressDetail "Left"] (key_move (-dx) 0);
  bind [`KeyPressDetail "Right"] (key_move dx 0);
  bind [`KeyPressDetail "Up"] (key_move 0 (-dx));
  bind [`KeyPressDetail "Down"] (key_move 0 dx);
  bind [`KeyPressDetail "plus"] (key_scale z);
  bind [`KeyPressDetail "KP_Add"] (key_scale z);
  bind [`KeyPressDetail "minus"] (key_scale (1. /. z));
  bind [`KeyPressDetail "KP_Subtract"] (key_scale (1. /. z));
  ()

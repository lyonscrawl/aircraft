let afficher_trajectoire = fun dep arr id cv ->
	View.line ~fill:`White ~width:2 ~tags:["traj"^(string_of_int id)] [dep; arr] cv;;

let maj_trajectoire = fun dep arr id cv ->
	let _ = View.delete_tag cv ("traj"^(string_of_int id)) in
	let _ = View.delete_tag cv ("man"^(string_of_int id)) in
	View.line ~fill:`White ~width:2 ~tags:["traj"^(string_of_int id)] [dep; arr] cv;;


let afficher_avion = fun p_a av traj i cv -> 
	let x,y = Pos_avion.recup_coords p_a in
	let azimut = Pos_avion.recup_azimut p_a in
	let _ = View.delete_tag cv ("avion"^(string_of_int i)) in
	let _ = View.delete_tag cv ("rond1"^(string_of_int i)) in
	let _ = View.delete_tag cv ("rond2"^(string_of_int i)) in
	let _ = View.delete_tag cv ("rond3"^(string_of_int i)) in
	let _ = View.delete_tag cv ("fleche"^(string_of_int i)) in
	let _ = View.text ~fill:`Blue ~anchor:`Nw ~tags:["avion"^(string_of_int i)] ~text: (string_of_float (Avion.recup_vitesse av)) (x+.10., y-.40.) cv in
	let _ =View.polygon ~outline:(`Color "#FF4901") ~width:2 ~tags:["avion"^(string_of_int i)] [ x , y -. 10. ; x +. 10. , y ;  x , y +. 10. ; x -. 10. , y ] cv in
	let _ = View.oval ~outline:(`Color "#FF4901") ~tags:["rond1"^(string_of_int i)] [x-.((Avion.recup_vitesse av)*.(sin azimut))/.3.-.3.,y-.((Avion.recup_vitesse av)*.(cos azimut))/.3.-.3.; x-.((Avion.recup_vitesse av)*.(sin azimut))/.3.+.3.,y-.((Avion.recup_vitesse av)*.(cos azimut))/.3.+.3.] cv in
	let _ = View.oval ~outline:(`Color "#FF4901") ~tags:["rond2"^(string_of_int i)] [x-.((Avion.recup_vitesse av)*.(sin azimut))*.2./.3.-.2.,y-.((Avion.recup_vitesse av)*.(cos azimut))*.2./.3.-.2.; x-.((Avion.recup_vitesse av)*.(sin azimut))*.2./.3.+.2.,y-.((Avion.recup_vitesse av)*.(cos azimut))*.2./.3.+.2.] cv in
	let _ = View.oval ~outline:(`Color "#FF4901") ~tags:["rond3"^(string_of_int i)] [x-.((Avion.recup_vitesse av)*.(sin azimut))-.2.,y-.((Avion.recup_vitesse av)*.(cos azimut))-.2.; x-.((Avion.recup_vitesse av)*.(sin azimut))+.2.,y-.((Avion.recup_vitesse av)*.(cos azimut))+.2.] cv in
	View.line ~fill:(`Color "#FF4901") ~width:3 ~arrow:`Last ~tags:["fleche"^(string_of_int i)] [x,y; x+.(Avion.recup_vitesse av)*.(sin azimut),y+.(Avion.recup_vitesse av)*.(cos azimut)] cv;;


let afficher_man = fun dep arr id liste cv ->
	let [pos1;pos2]=liste in
	View.line ~fill:`Green ~width:2 ~tags:["man"^(string_of_int id)] [dep;pos1;pos2; arr] cv;;

let afficher_conflit = fun pts1 pts2 id1 id2 cv ->
	let _ = View.line ~fill:`Red ~width:2 ~tags:["traj"^(string_of_int id1)] pts1 cv in
	View.line ~fill:`Red ~width:2 ~tags:["traj"^(string_of_int id2)] pts2 cv;;
	
let afficher_avion_init = fun p_a av traj i cv -> 
	let x,y = Pos_avion.recup_coords p_a in
	let azimut = Pos_avion.recup_azimut p_a in
	let _ = afficher_trajectoire (Trajectoire.recup_coords_depart traj) (Trajectoire.recup_coords_arrivee traj) (Trajectoire.recup_id traj) cv in
	let _ = View.text ~fill:`Blue ~anchor:`Nw ~tags:["avion"^(string_of_int i)] ~text: (string_of_float (Avion.recup_vitesse av)) (x+.10., y-.40.) cv in
	let _ =View.polygon ~outline:(`Color "#FF4901") ~width:5 ~tags:["avion"^(string_of_int i)] [ x , y -. 10. ; x +. 10. , y ;  x , y +. 10. ; x -. 10. , y ] cv in
	let _ = View.oval ~outline:(`Color "#FF4901") ~tags:["rond1"^(string_of_int i)] [x-.((Avion.recup_vitesse av)*.(sin azimut))/.3.-.3.,y-.((Avion.recup_vitesse av)*.(cos azimut))/.3.-.3.; x-.((Avion.recup_vitesse av)*.(sin azimut))/.3.+.3.,y-.((Avion.recup_vitesse av)*.(cos azimut))/.3.+.3.] cv in
	let _ = View.oval ~outline:(`Color "#FF4901") ~tags:["rond2"^(string_of_int i)] [x-.((Avion.recup_vitesse av)*.(sin azimut))*.2./.3.-.2.,y-.((Avion.recup_vitesse av)*.(cos azimut))*.2./.3.-.2.; x-.((Avion.recup_vitesse av)*.(sin azimut))*.2./.3.+.2.,y-.((Avion.recup_vitesse av)*.(cos azimut))*.2./.3.+.2.] cv in
	let _ = View.oval ~outline:(`Color "#FF4901") ~tags:["rond3"^(string_of_int i)] [x-.((Avion.recup_vitesse av)*.(sin azimut))-.2.,y-.((Avion.recup_vitesse av)*.(cos azimut))-.2.; x-.((Avion.recup_vitesse av)*.(sin azimut))+.2.,y-.((Avion.recup_vitesse av)*.(cos azimut))+.2.] cv in
	View.line ~fill:(`Color "#FF4901") ~width:3 ~arrow:`Last ~tags:["fleche"^(string_of_int i)] [x,y; x+.(Avion.recup_vitesse av)*.(sin azimut),y+.(Avion.recup_vitesse av)*.(cos azimut)] cv;;

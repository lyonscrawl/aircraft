type avion = { id: int; vitesse: float; temps_depart: float; temps_arrivee: float ; distance : float };;

let recup_avion_id = fun avion -> avion.id;;
let recup_avion_vitesse = fun avion -> avion.vitesse;;
let recup_avion_temps_depart = fun avion -> avion.temps_depart;;
let recup_avion_temps_arrivee = fun avion -> avion.temps_arrivee;;
let recup_avion_distance = fun avion -> avion.distance;;

let implementer_tab = fun liste_sim ->
	let tab=[|Liste_pos.create_liste (Avion.avion_vide ());Liste_pos.create_liste (Avion.avion_vide ());Liste_pos.create_liste (Avion.avion_vide ())|] in
	let rec aux = fun l ->
		match l with
		[] -> tab
		|h::t -> (let ind = (Annexe.obtenir_int (Avion.recup_nom (Vol.recup_avion (fst h))).[5]) in tab.(ind-1)<-(Pos_avion.recup_liste (snd h)); aux t) in
	aux liste_sim;;
	
let creer_avion = fun id vit tps_dep tps_arr dist ->
	{ id = id; vitesse = vit; temps_depart = tps_dep; temps_arrivee = tps_arr; distance = dist};;


let creer_tab_avi = fun liste_sim ->
	let tab=Array.init 3 (fun i -> (creer_avion i 0. 0. 0. 0.)) in
	let rec aux = fun l ->
		match l with 
		[] -> tab
		|h::t -> (let pos = (snd h) in 
			let indice= ((Annexe.obtenir_int (Avion.recup_nom (Pos_avion.recup_avion pos)).[5])-1) in 
			let vit = (Avion.recup_vitesse (Pos_avion.recup_avion pos)) in
			let instant = (Pos_avion.recup_tps pos)+.1. in
			let temps_fin = Liste_pos.tps_fin (Pos_avion.recup_liste pos) in
			let dist = Liste_pos.distance_a_faire (Pos_avion.recup_liste pos) instant in
			tab.(indice)<- (creer_avion indice vit instant temps_fin dist);
			aux t) in
	aux liste_sim;;






type vol = {plane:Avion.avion ; traj: Trajectoire.trajectoire; instant_depart: float; manoeuvre:bool};;

let create_vol = fun avi tra dep -> 
	{ plane = avi ; traj = tra ; instant_depart = dep; manoeuvre=false } ;;
	
let recup_avion = fun vo ->
	vo.plane;;
	
let recup_tps_depart = fun vo ->
	vo.instant_depart;;
	
let recup_trajectoire = fun vo ->
	vo.traj;;
	
let en_manoeuvre = fun vo ->
	vo.manoeuvre;;
	
let maj_dep = fun vo tps ->
	{ plane = vo.plane ; traj = vo.traj ; instant_depart = tps; manoeuvre=false } ;;
	
let maj_vitesse = fun vo vit ->
	{ plane = Avion.modif_vit (vo.plane) vit ; traj = vo.traj ; instant_depart = vo.instant_depart; manoeuvre=false } ;;
	
	
let maj_pts = fun vo traje ->
	{ plane =vo.plane ; traj = traje ; instant_depart = vo.instant_depart; manoeuvre=false } ;;
	




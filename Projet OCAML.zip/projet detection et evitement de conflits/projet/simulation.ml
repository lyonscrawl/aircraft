type simulation = { avions : (Vol.vol*Pos_avion.pos_avion) list; nb_avions: int;pas:float};;


let add_vol = fun sim vol_a_add pos_avion->
	{ avions = (vol_a_add,pos_avion) :: sim.avions ; nb_avions = sim.nb_avions + 1;pas=sim.pas};;
	
let recup_avions = fun sim ->
	sim.avions;;
	
let recup_nb_avions = fun sim ->
	sim.nb_avions;;
	
let initialiser_simulation = fun pas_sim->
	{avions=[];nb_avions=0;pas=pas_sim};;
	
	
let recup_pas = fun sim ->
	 sim.pas;;	

		
let enlever_vol = fun sim vol_a_enlever ->
	let rec aux = fun liste vol ->
		match liste with
		[] -> []
		| t::q when (Avion.recup_nom (Vol.recup_avion (fst t)))=(Avion.recup_nom (Vol.recup_avion vol)) ->  q
		| t::q -> t::(aux q vol) in
	let liste_finale = aux sim.avions vol_a_enlever in
	{avions=liste_finale;nb_avions=sim.nb_avions-1;pas=sim.pas};;
	

let afficher_simulation_init = fun sim cv->   
	let rec aux = fun liste i->
		match liste with 
		[] -> Printf.printf "Affichage simulation fini\n"
		| t::q -> let _ = Affichage.afficher_avion_init (snd t) (Vol.recup_avion (fst t)) (Vol.recup_trajectoire (fst t)) i cv; in aux q (i+1) in
	aux sim.avions 1;;


let afficher_simulation = fun sim cv->
	let rec aux = fun liste i->
		match liste with 
		[] -> () 
		| t::q -> let _ = Affichage.afficher_avion (snd t) (Vol.recup_avion (fst t)) (Vol.recup_trajectoire (fst t)) i cv in aux q (i+1) in
	aux sim.avions 1;;


let maj_des_vols = fun sim taille temps->
	let rec aux = fun l simu news_vols->
		match l with
		[] -> (simu,news_vols)
		|h::t ->(let vol = (fst h)  in 
			let futur=(Pos_avion.recup_coords (Pos_avion.avancer_avion (snd h) temps)) in 
			if (Pos_avion.sorti (fst futur) (snd futur) taille) 
				then aux t (enlever_vol simu vol) ((Vol.create_vol (Vol.recup_avion vol) (Vol.recup_trajectoire vol) (temps+.sim.pas))::news_vols) 
			else aux t simu news_vols) in
	aux sim.avions sim [];;
	
let distance = fun (x1,y1) (x2,y2) ->
	sqrt((x1-.x2)**2.+.(y1-.y2)**2.);;
	
let convergence = fun liste_pos1 liste_pos2 dist_min a1 a2->
	let rec aux1 = fun liste_pbs l1 ->
		match l1 with
		[] -> liste_pbs
		|a::q -> let rec aux2 = fun listebis l2 ->
			match l2 with
			[] -> aux1 listebis q
			|h::t when (Float.abs (fst (snd h)-.fst (snd a))<0.1) -> if (distance (fst h) (fst a)<dist_min) 
										   	then (aux1 ((fst (snd h),((a2,fst h),(a1,fst a)))::listebis) q ) 	
										   else aux1 listebis q
			|h::t -> (aux2 listebis t) in
		aux2 liste_pbs liste_pos2 in
	aux1 [] liste_pos1;;

let detect_conflit = fun sim dist-> 
	let rec aux1 = fun l conflits_liste ->
		match l with 
		[] -> conflits_liste
		|h::t -> let rec aux2 = fun l2 listebis->
			match l2 with
			[] -> aux1 t listebis
			|a::q -> ( if (Annexe.obtenir_int (Avion.recup_nom (Pos_avion.recup_avion (snd a))).[5])>(Annexe.obtenir_int (Avion.recup_nom(Pos_avion.recup_avion (snd h))).[5]) 
				   	then( aux2 q ((convergence (Liste_pos.recup_pos (Pos_avion.recup_liste (snd h))) (Liste_pos.recup_pos (Pos_avion.recup_liste (snd a))) dist (Pos_avion.recup_avion (snd h)) (Pos_avion.recup_avion (snd a)))@listebis)) 
				   else aux2 q listebis) in
		aux2 sim.avions conflits_liste in
	aux1 sim.avions [];;
	

let filtrer_conflits = fun conflit_liste ->
	let rec aux = fun liste_finale liste ->
		match liste with
		[] -> liste_finale
		|h::t -> aux (Annexe.tri_conflit h liste_finale) t in
	aux [] conflit_liste;;


let avancer_la_simu = fun simu temps ->
	let rec aux = fun l simul->
		match l with
		[] -> simul
		|h::t -> ( aux t {avions=(fst h,Pos_avion.avancer_avion (snd h) temps)::simul.avions;nb_avions=simul.nb_avions+1;pas=simul.pas}) in
	aux simu.avions (initialiser_simulation simu.pas);;
	
	

	
let correction_conflit = fun simul manoeuvres taille cv->
	let rec aux = fun liste sim liste_pts ->
		match liste with
		[] -> (sim,liste_pts)
		|h::t -> (let pos1=(snd h) in 
			let ind = ((Annexe.obtenir_int (Avion.recup_nom (Vol.recup_avion (fst h))).[5])-1) in
			let traj= Vol.recup_trajectoire (fst h) in
			let dep=Trajectoire.recup_coords_depart traj in
			let arr = Trajectoire.recup_coords_arrivee traj in
			let id = Trajectoire.recup_id traj in
			let pos,pts = Pos_avion.effectuer_man pos1 manoeuvres.(ind).(0) manoeuvres.(ind).(1) manoeuvres.(ind).(2) simul.pas (Trajectoire.calcul_azimut traj) taille in 
			if pts<>[] 
				then (let new_l= (((dep,arr),(id,pts))::liste_pts) 
			      in aux t (add_vol sim (fst h) pos) new_l)
			else aux t (add_vol sim (fst h) pos) liste_pts) in
	aux simul.avions (initialiser_simulation simul.pas) [];;

let ajouter_vols = fun simm news_vols temps taille->
	let rec aux = fun l simul liste->
		match l with
		[] -> simul,liste
		|h::t -> (Random.self_init ();
			let vitesse = float (30 + Random.int 30) in 
			let traj = Trajectoire.nouvelle_traj (Vol.recup_trajectoire h) taille in 
			let vol = Vol.maj_dep h temps in
			let vol = Vol.maj_pts vol traj in
			let vol = Vol.maj_vitesse vol vitesse in
			let pos = (Pos_avion.creer_pos (Vol.recup_avion vol) (Trajectoire.recup_coords_depart traj) temps) in 
			let pos = Pos_avion.initialiser_azimut pos traj in
			let pos = Pos_avion.maj_pos pos vol simul.pas in
			aux t (add_vol simul vol pos) (traj::liste)) in
	aux news_vols simm [];;

	
let maj_traj_liste = fun liste cv->
	let rec aux = fun l ->
		match l with
		[] -> ()
		| h::t -> let _ = Affichage.maj_trajectoire (Trajectoire.recup_coords_depart h) (Trajectoire.recup_coords_arrivee h) (Trajectoire.recup_id h) cv 
			  in aux t
	in aux liste;;


let ajouter_manoeuvres = fun pts cv ->
	let rec aux = fun l ->
		match l with 
		[] -> ()
		|h::t -> let ((dep,arr),(id,liste))=h in 
			  if (List.length liste = 2 ) 
			  	then let _ = Affichage.afficher_man dep arr id liste cv in aux t 
			  else aux t in 
	aux pts;;

let afficher_conflits = fun liste cv ->
	let rec aux = fun l ->
		match l with 
		[] -> ()
		|h::t -> let _ = Affichage.afficher_conflit (Conflit.recup_l1 h) (Conflit.recup_l2 h) (Annexe.obtenir_int (Avion.recup_nom (Conflit.recup_a1 h)).[5]) (Annexe.obtenir_int (Avion.recup_nom (Conflit.recup_a2 h)).[5]) cv in aux t in
	aux liste;;

let completer_simulation = fun sim n pts_depart_arrivee temps dist_min taille cv ->
	let rec aux = fun i simu points->
		match i,points with
		i,_ when i=(n+1)-> simu
		| i,hp::tp -> ( Random.self_init ();
					let vitesse = float (30 + Random.int 30) in 
					let av = (Avion.create_avion ("avion"^(string_of_int i)) vitesse) in
					let pos = (Pos_avion.creer_pos av (fst hp) temps) in
					let traj = (Trajectoire.create_traj (fst hp) (snd hp) i) in
					let pos = Pos_avion.initialiser_azimut pos traj in
					let vol = (Vol.create_vol av traj temps) in
					let pos = Pos_avion.maj_pos pos vol sim.pas in
					let simu = add_vol simu vol pos in
					aux (i+1) simu tp) in			
	let simm = aux 1 sim pts_depart_arrivee in
	let conflits_liste = filtrer_conflits (detect_conflit simm dist_min) in
	if conflits_liste=[] 
		then (afficher_simulation_init simm cv;simm) 
	else
	let manoeuvres_liste = Algo_gen.algo simm.avions simm.pas dist_min in
	let simmm,pts = correction_conflit simm manoeuvres_liste taille cv in
	(afficher_simulation_init simmm cv;
	afficher_conflits conflits_liste cv; 
	ajouter_manoeuvres pts cv; 
	simmm);;

let gestion_avancement = fun sim temps pas taille_fenetre dist_min cv->
	let simu,news_vols=maj_des_vols sim taille_fenetre temps in
	(
	if news_vols=[] 
		then (avancer_la_simu simu temps,0) 
	else 
	let simm,liste=ajouter_vols simu news_vols temps taille_fenetre in
	let conflits_liste = filtrer_conflits (detect_conflit simm dist_min) in
	if conflits_liste=[] 
		then (maj_traj_liste liste cv;(simm,1)) 
	else
	let manoeuvres_liste = Algo_gen.algo simm.avions simm.pas dist_min in
	(maj_traj_liste liste cv; 
	afficher_conflits conflits_liste cv; 
	let simmm,pts = correction_conflit simm manoeuvres_liste taille_fenetre cv in 
	(ajouter_manoeuvres pts cv; (simmm,1))));;
	


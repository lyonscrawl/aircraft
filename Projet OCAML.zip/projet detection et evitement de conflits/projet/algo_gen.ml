let _taille_population = 100;;

let calcul_nombre_individu = fun taille_pop pourcentage ->
	int_of_float( float_of_int(taille_pop) *. pourcentage );;
	
let nb_mutation = calcul_nombre_individu _taille_population 0.4;;
let nb_croisement = calcul_nombre_individu _taille_population 0.4;;
let nb_anciens_individu = calcul_nombre_individu _taille_population 0.2;;

let _taille_max_generation = 1000;;
let _fitness_max = 3./.2.;;

let _min_alpha = -0.5;;
let _max_alpha = 0.5;;
let _pas_alpha = 0.05;;

let _nombre_alpha_possible = int_of_float((_max_alpha -. _min_alpha)/._pas_alpha) + 1;;

let _liste_alpha_possible = Array.init _nombre_alpha_possible (fun i -> _min_alpha +. float_of_int(i) *. _pas_alpha);;

let alpha_aleatoire = fun () -> let indice = Random.int _nombre_alpha_possible in
                                _liste_alpha_possible.(indice);;

let manoeuvre_aleatoire = fun avion ->
	let ta = Probleme.recup_avion_temps_arrivee avion in
	let td = Probleme.recup_avion_temps_depart avion in
	let duree = ta -. td in
	let t_0 = td +. Random.float duree in
	let t_1 = t_0 +. Random.float (ta -. t_0) in
	let alpha = alpha_aleatoire() in
	[| t_0 ; t_1 ; alpha |] ;;
	
	
let individu_aleatoire = fun tableau_avions nb_avions ->
	Array.init nb_avions (fun i -> manoeuvre_aleatoire tableau_avions.(i) );;
	
let population_aleatoire = fun tableau_avions nb_avions taille_pop ->
	Array.init taille_pop (fun i -> individu_aleatoire tableau_avions nb_avions);;
	
let calcul_rallongement = fun avion manoeuvre ->
	let distance_initiale = Probleme.recup_avion_distance avion in
	let vitesse = Probleme.recup_avion_vitesse avion in 
	let t_0 = manoeuvre.(0) in
	let t_1 = manoeuvre.(1) in
	let alpha = manoeuvre.(2) in
	let td = Probleme.recup_avion_temps_depart avion in
	let cosinus_a = Float.cos alpha in
	let d1 = (t_0 -. td) *. vitesse in
	let d2 = (t_1 -. t_0) *. vitesse /. cosinus_a in
	let d3 = Float.sqrt ( (distance_initiale -. d1)**2. +. (d2)**2. -. 2. *. (distance_initiale -. d1) *. (d2) *. cosinus_a ) in
	let r = d1 +. d2 +. d3 -. distance_initiale in if r > 0. then r else 0.;;
	
let mesure_conflit = fun i j individu liste_sim pas dist_min->
	let manoeuvre_avion1 = individu.(i) in
	let manoeuvre_avion2 = individu.(j) in 
	let tableau_trajectoires= Probleme.implementer_tab liste_sim in
	let av1= (Liste_pos.recup_avion (tableau_trajectoires.(i))) in
	let av2= (Liste_pos.recup_avion (tableau_trajectoires.(j))) in
	let traj1 = Annexe.recup_traj (Avion.recup_nom av1) liste_sim in
	let traj2 = Annexe.recup_traj (Avion.recup_nom av2) liste_sim in
	let azim1 = (Trajectoire.calcul_azimut traj1) in 
	let azim2 = (Trajectoire.calcul_azimut traj2) in 
	let nouvelle_trajectoire1 = fst (Liste_pos.modifie_traj tableau_trajectoires.(i) manoeuvre_avion1.(0) manoeuvre_avion1.(1) manoeuvre_avion1.(2) pas (Avion.recup_vitesse (av1)) azim1 1200.) in
	if Liste_pos.sort_du_cadre nouvelle_trajectoire1 1200. 
		then 1. 
	else
	let nouvelle_trajectoire2 = fst (Liste_pos.modifie_traj tableau_trajectoires.(j) manoeuvre_avion2.(0) manoeuvre_avion2.(1) manoeuvre_avion2.(2) pas (Avion.recup_vitesse (av2)) azim2 1200.) in
	if Liste_pos.sort_du_cadre nouvelle_trajectoire2 1200. 
		then 1. 
	else
	let res = Annexe.conflit (Liste_pos.recup_pos nouvelle_trajectoire1) (Liste_pos.recup_pos nouvelle_trajectoire2) dist_min in
	 res;;
		
	
let matrice_evaluation = fun tableau_avions nb_avions individu liste_sim pas dist_min->
	Array.init nb_avions ( fun i -> Array.init nb_avions ( fun j -> if i = j then calcul_rallongement tableau_avions.(i) individu.(i) 
									else mesure_conflit i j individu liste_sim pas dist_min) );;
									
									
let predicat_test_zero = fun tableau -> 
	Array.for_all (fun p -> p = 0.) tableau;;	
	
							
let elements_hors_diagonale = fun matrice ->
	let taille = Array.length matrice in 
	Array.init taille (fun i -> Array.init taille (fun j -> if i = j then 0. else matrice.(i).(j) ) );;
	
let zero_hors_diagonale = fun matrice ->
	Array.for_all predicat_test_zero (elements_hors_diagonale matrice);;

	
let somme_elements_matrice = fun matrice ->
	Array.fold_left (+.) 0. (Array.init (Array.length matrice) (fun i -> Array.fold_left (+.) 0. matrice.(i)) );;
			
let fitness_individu = fun tableau_avions nb_avions individu liste_sim pas dist_min->
	let c = matrice_evaluation tableau_avions nb_avions individu liste_sim pas dist_min in
	let pas_conflit = zero_hors_diagonale c in 
	let somme = somme_elements_matrice c in
	if pas_conflit 
		then (0.5 +. 1./.(1.+.somme)) 
	else (1./.(2.+.somme));;	

let evaluation_population = fun population tableau_avions nb_avions liste_sim pas dist_min->
	let eval = Array.init (Array.length population) ( fun i -> [| float_of_int(i) ; fitness_individu tableau_avions nb_avions population.(i) liste_sim pas dist_min|]) in
	Array.fast_sort (fun x y -> - (compare x.(1) y.(1))) eval; eval;;


	
let rearrangement_population = fun population evaluation ->
	Array.init (Array.length population) ( fun i -> population.( int_of_float( evaluation.(i).(0)) ) );; 

	
	
let tableau_score = fun evaluation ->
	let somme_fitness = Array.fold_left (+.) 0. (Array.init _taille_population (fun i -> evaluation.(i).(1))) in 
	let m = Array.init _taille_population (fun i -> evaluation.(i).(1) /. somme_fitness) in
	Array.mapi (fun i x -> Array.fold_left (+.) m.(i) (Array.init i (fun j -> m.(j)))) m;;
	
	

	
let plus_proche_alpha = fun alpha liste_alpha ->
	let ecart = Array.map (fun elt -> Float.abs (alpha -. elt) ) liste_alpha in
	let mini = Array.fold_left (Float.min) _pas_alpha ecart in
	if alpha < _min_alpha 
		then _min_alpha 
	else if alpha > _max_alpha 
		then _max_alpha
	else 
	let rec aux = fun i ->
		match i with
		i when ecart.(i)=mini -> i 
		|i -> aux (i+1) in
	let indice = aux 0 in
	liste_alpha.(indice);;
	


let scale = fun t0 t1 td ta nouveau_alpha ancien_alpha ->
	let t_0,cond1 = if t0<td then td,1 else t0,0 in
	let t_1,cond2 = if t1>ta then ta,1 else t1,0 in 
	let t_0_fin,t_1_fin,cond3 = if t_0>t_1 then td,ta,1 else t_0,t_1,0 in
	if cond1=1 || cond2=1 ||cond3=1 then [|t_0_fin;t_1_fin;ancien_alpha|] else [|t_0_fin;t_1_fin;nouveau_alpha|];;	

let croisement_avionj = fun individu1 fitness1 individu2 fitness2 avionj tableau_avions-> 
	let lambda1 = Random.float 1. in
	let lambda2 = Random.float 1. in
	let lambda3 = Random.float 1. in
	let ta = Probleme.recup_avion_temps_arrivee tableau_avions.(avionj) in
	let td = Probleme.recup_avion_temps_depart tableau_avions.(avionj) in
	let aux1 = fun lambda a_ind a_fit b_ind b_fit i ->
		let a = a_ind.(avionj) in
		let b = b_ind.(avionj) in
		if lambda >= 0.5 
			then lambda *. a.(i) +. (1. -. lambda) *. b.(i)
		else lambda *. a.(i) +. (1. -. lambda) *. b.(i) in
	let aux2 = fun lambda ind1 fit1 ind2 fit2 i->
		if fit1 >= fit2 
			then aux1 lambda ind1 fit1 ind2 fit2 i			
		else aux1 lambda ind2 fit2 ind1 fit1 i in
	let t0 = aux2 lambda1 individu1 fitness1 individu2 fitness2 0 in
	let t1 = aux2 lambda2 individu1 fitness1 individu2 fitness2 1 in
	let alpha = aux2 lambda3 individu1 fitness1 individu2 fitness2 2 in
	let new_alpha = plus_proche_alpha alpha _liste_alpha_possible in
	let biggest_alpha = if Float.abs(individu1.(avionj).(2)) > Float.abs(individu2.(avionj).(2)) then individu1.(avionj).(2) else individu2.(avionj).(2) in 
	scale t0 t1 td ta new_alpha biggest_alpha;;

	
let croisement_individu = fun individu1 fitness1 individu2 fitness2 tableau_avions->
	let nb_avion = Array.length individu1 in
	Array.init nb_avion (fun j -> croisement_avionj individu1 fitness1 individu2 fitness2 j tableau_avions);;
	
let operation = fun x y ->
	let a = Random.float 1. in
	if a <= 0.5 
		then x +. y 
	else x -. y;;
	

	
let mutation_avionj = fun individu avionj tableau_avions ->
	let manoeuvre = individu.(avionj) in
	let ta = Probleme.recup_avion_temps_arrivee tableau_avions.(avionj) in
	let td = Probleme.recup_avion_temps_depart tableau_avions.(avionj) in
	let duree = ta -. td in
	let t0 = operation manoeuvre.(0) (Random.float duree) in
	let t1 = operation manoeuvre.(1) (Random.float duree) in
	let alpha = plus_proche_alpha (manoeuvre.(2) +. alpha_aleatoire()) _liste_alpha_possible in 
	scale t0 t1 td ta alpha alpha;;
	
let mutation_individu = fun individu tableau_avions ->
	let nb_avion = Array.length individu in
	Array.init nb_avion (fun j -> mutation_avionj individu j tableau_avions);;	
	
let choix_individu_segment = fun p tableau_de_score ->
	let rec aux = fun i max ->
		if i = max 
			then max
		else if i = 0 && p <= tableau_de_score.(i+1) 
	 	     	then 0
		else if tableau_de_score.(i) <= p && p <= tableau_de_score.(i+1) 
			then i 
		else aux (i+1) max in
		aux 0 (Array.length tableau_de_score);;


	
let evolution_population = fun population_evaluee evaluation tableau_avions ->
	let tab_score = tableau_score evaluation in
	Array.init (Array.length population_evaluee) (fun i -> if i < nb_croisement then begin
								let p1 = Random.float 1. in
								let p2 = Random.float 1. in
								let indice_individu1 = choix_individu_segment p1 tab_score in
								let indice_individu2 = choix_individu_segment p2 tab_score in
								let individu1 = population_evaluee.(indice_individu1) in
								let fitness1 = evaluation.(indice_individu1).(0) in
								let individu2 = population_evaluee.(indice_individu2) in
								let fitness2 = evaluation.(indice_individu2).(0) in
								croisement_individu individu1 fitness1 individu2 fitness2 tableau_avions
								end
								
							else if i < (nb_croisement + nb_mutation) then begin
								let p = Random.float 1. in
								let indice_individu = choix_individu_segment p tab_score in
								mutation_individu population_evaluee.(indice_individu) tableau_avions
								end
								
							else begin
								let p = Random.float 1. in
								let indice_individu = choix_individu_segment p tab_score in
								population_evaluee.(indice_individu)
								end );;
					
	
			
let genetic_algortihm = fun tableau_avions nb_avions taille_pop taille_generation epsilon liste_sim pas dist_min->
	let population = ref (population_aleatoire tableau_avions nb_avions taille_pop) in 
	let evaluation = ref (evaluation_population !population tableau_avions nb_avions liste_sim pas dist_min) in
	let population_evaluee = ref (rearrangement_population !population !evaluation) in
	let fit_max = ref (!evaluation).(0).(1) in
	let nb_generation = ref 0 in 
	while Float.abs (!fit_max -. _fitness_max) > epsilon && !nb_generation < taille_generation do
		nb_generation := !nb_generation + 1;		
		population := evolution_population !population_evaluee !evaluation tableau_avions;
		evaluation := evaluation_population !population tableau_avions nb_avions liste_sim pas dist_min;
		population_evaluee := rearrangement_population !population !evaluation;
		fit_max := (!evaluation).(0).(1);
		done;
	(!population_evaluee).(0);;
	
	


let algo = fun liste_sim pas dist_min->
	let tableau_avi = Probleme.creer_tab_avi liste_sim in
	let nb_avi=Array.length tableau_avi in
	let epsilon = 0.001 in
	genetic_algortihm tableau_avi nb_avi _taille_population _taille_max_generation epsilon liste_sim pas dist_min ;;
  	

	
  	
  	
  	
  	
  	

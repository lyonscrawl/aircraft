type liste_pos = {plane:Avion.avion; positions: (View.xy * (float*float)) list};;

let create_liste = fun avi ->
	{plane=avi;positions=[]};;
	
let recup_pos = fun liste ->
	liste.positions;;
	
let recup_avion = fun liste ->
	liste.plane;;
	
let sorti = fun x y taille_fenetre ->
	x>(taille_fenetre-.100.)||y>(taille_fenetre-.100.)||x<100.||y<100.;;
	
let chercher_une_pos = fun liste i ->
	let rec aux = fun l j ->
		match l,j with 
		[],_ -> (((0.,0.),(0.,0.)),0)
		|a::q,0 -> (a,(i+1))
		|a::q,j -> aux q (j-1) in
	aux liste i;;
	
let sort_du_cadre = fun liste taille->
	let rec aux = fun l ->
		match l with
		[] -> false
		|h::t -> let (x,y)=(fst h) in if (sorti x y taille) then true else aux t in
	aux liste.positions;;
	
let implementer_pos = fun vol pas->
	let taille_fenetre=1200. in
	let av=Vol.recup_avion vol in
	let vit= Avion.recup_vitesse av in
	let traj=Vol.recup_trajectoire vol in
	let x_dep,y_dep=Trajectoire.recup_coords_depart traj in
	let azimut = Trajectoire.calcul_azimut traj in
	let rec aux = fun liste x y tps->
		match x,y,liste with
		x,y,h::t when (sorti x y taille_fenetre) -> t
		|x,y,liste -> let new_x=x+.vit*.pas*.(sin azimut) and new_y=y+.vit*.pas*.(cos azimut) in 
		              (aux (((new_x,new_y),(tps,azimut))::liste) new_x new_y (tps+.pas)) in
	{plane=av;positions=List.rev (aux [] x_dep y_dep (Vol.recup_tps_depart vol))};; 
		
	
let pos_finale = fun liste ->
	let h::t = (List.rev liste.positions) in
	fst h;;
	
let distance = fun (x1,y1) (x2,y2) ->
	sqrt((x1-.x2)**2.+.(y1-.y2)**2.);;
	
let tps_fin = fun liste ->
	let n = List.length liste.positions in
	(fst (snd (List.nth liste.positions (n-1))));;
	
let distance_a_faire = fun liste temps ->
	let rec aux = fun l somme passe last_x last_y->
	match l with
	[] -> somme 
	| h::t -> let ((new_x,new_y),(tps,azimut)) = h in 
		if last_x=0.&&last_y=0. 
			then if tps=temps 
				then aux t somme 1 new_x new_y 
			else aux t somme passe new_x new_y
		else if passe=0 
			then if tps=temps 
				then aux t somme 1 new_x new_y
			else aux t somme passe new_x new_y
		else aux t (somme+.(distance (new_x,new_y) (last_x,last_y))) passe new_x new_y in
	aux liste.positions 0. 0 0. 0.;;
		
	
let premier_azim = fun liste ->
	let h::t=liste.positions in
	snd (snd h);;
	
let modifie_traj = fun liste t0 t1 alpha pas vit azim_prev taille->
	if alpha =0. then (liste,[]) else
	let rec aux = fun l new_l azim liste_pts->
	match l with
	[] -> (new_l,liste_pts)
	|h::t -> let temps = (fst (snd h)) and (new_x,new_y)=(fst h) in (
	         if (t1-.t0)<pas 
	         	then aux [] ((List.rev l)@new_l) azim liste_pts 
	         else
	         if (temps<t0)&&((t0-.temps) < pas) 
	         	then aux t (h::new_l) ((snd (snd h))+.alpha) ((new_x,new_y)::liste_pts)
	         else 
	         if (temps<t0) 
	         	then aux t (h::new_l) azim liste_pts 
	         else
		 let rec aux2 = fun newl azi x y tps listebis->
			(if (tps>=t0)&&(tps<t1)&&((t1-.tps)<pas) 
				then let a::q=newl in
				let vx,vy = fst a in 
				let xt1=vx+.vit*.(t1-.tps)*.(sin azi) and yt1=vy+.vit*.(t1-.tps)*.(cos azi) in
				let coords = (pos_finale liste) in
				let coords_fin = if azim_prev=0. then (fst coords,taille-.100.) else (taille-.100.,snd coords) in
				let d1= distance (xt1,yt1) coords_fin in
				let d2= if azim_prev=0. then ((fst coords_fin)-.xt1) else ((snd coords_fin)-.yt1) in
				let f_azi = if azim_prev=0. then (asin (d2/.d1)) else (acos(-1.)/.2.-.asin (d2/.d1)) in
				let f_x = xt1+.vit*.(tps+.pas-.t1)*.(sin f_azi) in
				let f_y = yt1+.vit*.(tps+.pas-.t1)*.(cos f_azi) in
				aux2 (((x,y),(tps,azi))::newl) f_azi f_x f_y (tps+.pas) ((xt1,yt1)::listebis)
			else if (tps>=t0)&&(tps<t1) 
				then let f_x=x+.vit*.pas*.(sin azi) and f_y=y+.vit*.pas*.(cos azi) in
				aux2 (((x,y),(tps,azi))::newl) azi f_x f_y (tps+.pas) listebis
			else let f_x=x+.vit*.pas*.(sin azi) and f_y=y+.vit*.pas*.(cos azi) in 
			if (sorti f_x f_y 1200.) 
				then aux [] newl azi listebis
			else aux2 (((x,y),(tps,azi))::newl) azi f_x f_y (tps+.pas) listebis)  in
			aux2 new_l azim new_x new_y temps liste_pts)  in
	let (pos,liste_pt)=(aux liste.positions [] (premier_azim liste) []) in
	let fin = {plane=liste.plane;positions=List.rev pos} in
	(fin,List.rev liste_pt);;

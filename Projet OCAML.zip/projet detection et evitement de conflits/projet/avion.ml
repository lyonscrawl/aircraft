type avion= {nom:string ; vitesse:float };;

let create_avion = fun name vit ->
	{nom = name; vitesse = vit};;
	
let recup_vitesse = fun av ->
	av.vitesse;;
	
let recup_nom = fun av ->
	av.nom;;
	
let avion_vide = fun () -> {nom = "a"; vitesse = 0.};;
	
let modif_vit = fun av vit ->
	{nom=av.nom;vitesse=vit};;

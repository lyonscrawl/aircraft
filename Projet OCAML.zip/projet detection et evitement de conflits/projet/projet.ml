let () =
  let playing = ref true in
  let tps = ref 0. in
  let pas = 0.5 in
  let dist_min=100. in
  let taille_fenetre = 1200. in
  let liste_pts_depart_arrivee = Trajectoire.generer_3_pts_dep_arr taille_fenetre in
  let sim = ref (Simulation.initialiser_simulation pas) in
  let top = View.openTk() in
  let f0 = View.canvas  ~width:(1408) ~height:(140) ~background:(`Color "#FFFFFF") top in
  let f1 = View.canvas  ~width:(1408) ~height:(80) ~background:(`Color "#FFFFFF") f0 in
  let _ = Canvas.create_bitmap
          ~x:200 ~y:45 ~foreground:(`Blue)
          ~bitmap:(`File "./pics/enac.xbm")
          f1 in
  let _ = View.text ~anchor:`Center ~fill:`Black ~font:"TkDefaultFont" 
          ~text:"<<< PROJET OCAML/IA : RESOLUTION DE CONFLITS EN CONTINU PAR ALGORITHME GENETIQUE >>>" 
          ~tags:["rect"] 
          (700., 40.0) f1 in
  let _ = View.text ~anchor:`Center ~fill:(`Color "#FF4901") ~font:"TkDefaultFont" 
          ~text:"Equipe projet: Lorenzo De Angelis - Mateo Michaux - Yanne Sidibe (Ver. 1.0.0)" 
          ~tags:["rect"] 
          (700., 60.0) f1 in
  let _ = Canvas.create_bitmap
          ~x:1200 ~y:40 ~foreground:(`Color "#FF4901")
          ~bitmap:(`File "./pics/present.xbm")
          f1 in
  let f2 = View.canvas  ~width:(1408) ~height:(60) ~background:(`Color "#FFF48D") f0 in
  let b2 = View.canvas  ~width:(352) ~height:(60) ~background:(`Color "#FFF48D") f2 in
  let _ = Canvas.create_bitmap
          ~x:180 ~y:30 ~foreground:(`Color "#FF4901")
          ~bitmap:(`File "./pics/about.xbm")
          b2 in
  let b3 = View.canvas  ~width:(352) ~height:(60) ~background:(`Color "#FFF48D") f2 in
  let _ = Canvas.create_bitmap
          ~x:180 ~y:30 ~foreground:(`Color "#FF4901")
          ~bitmap:(`File "./pics/pause.xbm")
          b3 in
  let b4 = View.canvas  ~width:(352) ~height:(60) ~background:(`Color "#FFF48D") f2 in
  let _ = Canvas.create_bitmap
          ~x:180 ~y:30 ~foreground:(`Color "#FF4901")
          ~bitmap:(`File "./pics/play.xbm")
          b4 in
  let cv = View.canvas  ~width:(1408) ~height:(688) ~background:(`Blue) top in
  let _ = View.rectangle ~fill:(`Color "#0080FF") ~tags:["rect"] [50., 50.; taille_fenetre-.50., taille_fenetre-.50.] cv in
  sim := Simulation.completer_simulation (!sim) 3 liste_pts_depart_arrivee (!tps) dist_min taille_fenetre cv;
  
  
  Tk.pack ~fill:`Both ~expand:false [f0];
  Tk.pack ~fill:`Y ~side:`Top ~expand:false [f1];
  Tk.pack ~fill:`Y ~side:`Bottom ~expand:false [f2];
  Tk.pack ~side:`Left ~expand:false [b2];
  Tk.pack ~side:`Left ~expand:false [b3];
  Tk.pack ~side:`Left ~expand:false [b4];
  Tk.pack ~fill:`Both ~expand:true [cv];
  View.see_all cv;
  View.nav_bind cv;
  
  Tk.bind
    ~events:[`KeyPressDetail "space"]
    ~action:(fun _ -> View.see_all cv)
    cv;


  (* Action sur le bouton pause *)
  Tk.bind
    ~events:[`ButtonPress]
    ~action:(fun _ ->
    let dialog = Dialog.create
    ~parent:top
    ~title:"Simulation en pause"
    ~message:"Voulez-vous continuer la simulation ?"
    ~buttons:["Non";"Oui"]
    ~default:1
    ()
    in
    if dialog=0 then (print_endline "Bye"; flush stdout; View.closeTk())
    else (print_endline "OK"; flush stdout))
    b3;
  (* Action sur le bouton play *)
  Tk.bind
    ~events:[`ButtonPress]
    ~action:(fun _ -> (playing:=true))
    b4;
  (* Action sur le bouton settings *)
  Tk.bind
    ~events:[`ButtonPress]
    ~action:(fun _ -> (let dialog = Dialog.create
    ~parent:top
    ~title:"A Propos"
    ~message:"Equipe projet :\n--> Lorenzo De Angelis\n--> Mateo Michaux\n--> Yanne Sidibe\n\nVersion 1.0.0\n\nNB : Appuyer sur la touche Q pour quitter l'application."
    ~buttons:["OK"]
    ~default:0
    ()
      in (print_endline "OK"; flush stdout)))
    b2;
  let t2= ref (Sys.time()) in
  let check= ref 0 in
  let var = ref (!sim,!check) in
  let t= ref (Sys.time()) in
  let i=ref 1 in
  while (!playing = true) do
  	(if (Sys.time()-.(!t2) > ((float !i)*.pas)) then
	  (
	  tps := Sys.time()-.(!t2);
	  t:=Sys.time();
	  var:=Simulation.gestion_avancement (!sim) (!tps) pas taille_fenetre dist_min cv;
	  sim:=fst (!var);
	  check:=snd (!var);
	  if (!check)=1 then(
	  	t2:=(Sys.time())-.(!t)+.(!t2) )
	  else ();
	  let _ = Simulation.afficher_simulation (!sim) cv in
	  View.see_all cv;
	  View.nav_bind cv;
	  Tk.bind
	    ~events:[`KeyPressDetail "space"]
	    ~action:(fun _ -> View.see_all cv)
	    cv;
	    incr i;
	    ))
	    
	  done;
	  View.mainLoop();;

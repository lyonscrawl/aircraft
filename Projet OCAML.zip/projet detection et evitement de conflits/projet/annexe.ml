let generer_noms_avions = fun n ->
	let rec aux = fun i liste ->
		match i with 
		0 -> liste 
		|i -> aux (i-1) (("avion"^(string_of_int i))::liste) in
	aux n [];;
	
let distance = fun (x1,y1) (x2,y2) ->
	sqrt((x1-.x2)**2.+.(y1-.y2)**2.);;
	
let tri_conflit = fun element liste ->
	let (a1,pos1)= fst (snd element) and (a2,pos2)=snd (snd element) in
	let temps = fst element in
	let rec aux = fun l ->
		match l with 
		[] -> [Conflit.creer_conflit a1 a2 temps (distance pos1 pos2) pos1 pos2 [pos1] [pos2]]
		|h::t -> let av1=Conflit.recup_a1 h and av2=Conflit.recup_a2 h in 
		         if (av1,av2)=(a1,a2)||(av1,av2)=(a2,a1) 
		         	then let dist = distance pos1 pos2 in 
		         	     if (dist<Conflit.recup_dist h) 
		         	     	then ((Conflit.creer_conflit a1 a2 temps (distance pos1 pos2) pos1 pos2 (pos1::(Conflit.recup_l1 h)) (pos2::(Conflit.recup_l2 h)))::t) 
		         	     else (Conflit.implementer_listes h pos1 pos2)::t 
		         else (h::(aux t)) in
	aux liste;;
	
let recup_traj = fun nom liste_sim ->
	let rec aux = fun l ->
		match l with
		[] -> Trajectoire.create_traj (0.,0.) (0.,0.) 0
		|h::t -> let vol = (fst h) in 
		if (Avion.recup_nom (Vol.recup_avion vol))=nom 
			then (Vol.recup_trajectoire vol) 
		else (aux t) in
	aux liste_sim;;
	
let conflit = fun l1 l2 dist_min->
	let rec aux1 = fun l ->
		match l with
		[] -> 0.
		|h::t -> let rec aux2 = fun liste ->
			match liste with
			[] -> aux1 t 
			|a::q -> if (Float.abs (fst (snd h)-.fst (snd a))<0.1) 
					then  if (distance (fst h) (fst a)<dist_min) 
						then 1. 
					else aux2 q 
				else aux2 q in
		aux2 l2 in
	aux1 l1;;


let obtenir_int = fun c ->
	if c='0' then 0 else
	if c='1' then 1 else
	if c='2' then 2 else 
	if c='3' then 3 else 0;;

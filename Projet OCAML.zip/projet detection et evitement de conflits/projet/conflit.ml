type conflit = {avion1:Avion.avion; avion2:Avion.avion; instant:float; distance:float; position1:View.xy;position2:View.xy;liste1: View.xy list;liste2: View.xy list};;

let creer_conflit = fun a1 a2 t dist p1 p2 l1 l2->
	{avion1=a1;avion2=a2;instant=t;distance=dist;position1=p1;position2=p2;liste1= l1;liste2= l2};;
	
let recup_a1 = fun conf ->
	conf.avion1;;
	
let recup_a2 = fun conf ->
	conf.avion2;;

let recup_temps = fun conf ->
	conf.instant;;
	
let recup_dist = fun conf ->
	conf.distance;;
	
let recup_p1 = fun conf ->
	conf.position1;;
	
let recup_p2 = fun conf ->
	conf.position2;;
	
let recup_l1 = fun conf ->
	conf.liste1;;
	
let recup_l2 = fun conf ->
	conf.liste2;;
	
let implementer_listes = fun conf p1 p2 ->
	{avion1=conf.avion1;avion2=conf.avion2;instant=conf.instant;distance=conf.distance;position1=conf.position1;position2=conf.position2;liste1= (p1::(conf.liste1));liste2= (p2::(conf.liste2))};;
	

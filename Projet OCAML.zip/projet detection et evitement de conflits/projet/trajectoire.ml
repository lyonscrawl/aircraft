type trajectoire = { id:int;depart: View.xy; arrivee:View.xy};;

let create_traj = fun dep arr i->
	{id=i;depart = dep; arrivee = arr};;
	
let recup_coords_depart = fun traj ->
	traj.depart;;
	
let recup_coords_arrivee = fun traj ->
	traj.arrivee;;
	
let calcul_azimut = fun traj ->
	let x_dep,y_dep = traj.depart in
	let x_arr,y_arr = traj.arrivee in
	atan ((x_arr-.x_dep)/.(y_arr-.y_dep));;
	
let recup_id = fun traj ->
	traj.id;;
	
let generer_3_pts_dep_arr = fun taille ->
	Random.self_init ();
	let val1=Random.int (int_of_float (taille*.0.2)) in
	Random.self_init ();
	let val2=Random.int (int_of_float (taille*.0.3)) in
	Random.self_init ();
	let val3=Random.int (int_of_float (taille*.0.6)) in
	let pts1= ((100.,float ((int_of_float (taille*.0.3))+val1)),(taille-.100.,float ((int_of_float (taille*.0.3))+val1))) in
	let pts2=((100.,float ((int_of_float (taille*.0.6))+val2)),(taille-.100.,float ((int_of_float (taille*.0.6))+val2))) in
	let pts3= ((float ((int_of_float (taille*.0.3))+val3),100.),(float ((int_of_float (taille*.0.3))+val3),taille-.100.)) in
	[pts1;pts2;pts3];;
	
	
let nouvelle_traj = fun traj taille->
	let x_dep,y_dep=traj.depart and x_arr,y_arr=traj.arrivee in
	let tirage,intervalle,orientation= 
	if x_dep=100. 
		then if y_dep < (taille*.0.5+.1.) 
			then 0.2,0.3,"hori" 
		     else 0.3,0.6,"hori"
	else 0.6,0.3,"vert" in
	Random.self_init ();
	let vall=Random.int (int_of_float (taille*.tirage)) in
	if orientation="hori" 
		then {id=traj.id;depart=(x_dep,float ((int_of_float (taille*.intervalle))+vall));arrivee=(x_arr,float ((int_of_float (taille*.intervalle))+vall))}
	else {id=traj.id;depart=(float ((int_of_float (taille*.intervalle))+vall),y_dep);arrivee=(float ((int_of_float (taille*.intervalle))+vall),y_arr)};;
	
let obtenir_pts_depart_arrivee = fun liste_trajectoires ->
	let rec aux = fun liste_traj liste_pts->
		match liste_traj with
		[] -> liste_pts
		|h::t -> aux t ((h.depart,h.arrivee)::liste_pts) in
	aux liste_trajectoires [];;
	
